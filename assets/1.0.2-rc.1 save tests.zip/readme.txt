Testing 1.0.2-rc.1
Tested using default settings.
classic world was saved using OfflineDATSave jar mod

in-20091223 w/ save
☑️ convert c0.30_01c world
☑️ load in-20091223 w/ save world

in-20091231 w/ save
☑️ convert c0.30_01c world
☑️ load in-20091223 w/ save world
☑️ load in-20091231 w/ save world

in-20100104 w/ save
☑️ convert c0.30_01c world
☑️ load in-20091223 w/ save world
☑️ load in-20091231 w/ save world
☑️ load in-20100104 w/ save world

in-20100110 w/ save
☑️ convert c0.30_01c world
☑️ load in-20091223 w/ save world
☑️ load in-20091231 w/ save world
☑️ load in-20100104 w/ save world
☑️ load in-20100110 w/ save world

in-20100125
As the default settings have save block items enabled, the world has to be saved in 110 before loading in vanilla, thus only testing 110.
☑️ load in-20100110 w/ save world

in-20100223
As the default settings have save block items enabled, the world has to be saved in 110 before loading in vanilla, thus only testing 110 (and vanilla).
☑️ load in-20100110 w/ save world
☑️ load in-20100125 world